package bigoh;

/**
 * @author John Stout
 */
public class bigoh_test {
	public static void main(String args[]) {
		bigO.indexTest();
		Subsequence.subsequencer();
	}

}
